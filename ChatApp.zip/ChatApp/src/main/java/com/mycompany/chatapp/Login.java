package com.mycompany.chatapp;

public class Login {

    // These variables store the user's details
    String username;
    String password;
    String phonenumber;

    // Check username: must contain "_" and be no more than 5 characters
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password complexity
    public boolean checkPasswordComplexity(String password) {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        // Loop through each character in password
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } 
            else if (Character.isDigit(c)) {
                hasNumber = true;
            } 
            else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        // Password must be at least 8 characters and meet all conditions
        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // Check South African phone number format
    public boolean checkCellPhoneNumber(String phone) {
        // Must start with +27 and be exactly 12 characters long
        return phone.startsWith("+27") && phone.length() == 12;
    }

    // Return login status message
    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + username + " it is good to see you again.";
        } else {
            return "Username or password invalid, please try again.";
        }
    }

    // Check login credentials
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // Register user with validation checks
    public String registerUser(String username, String password, String phoneNumber) {

        // Validate username
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        // Validate password
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains atleast eight characters, a capital letter, a number, and a special character.";
        }

        // Validate phone number
        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // Save user details if all checks pass
        this.username = username;
        this.password = password;
        this.phonenumber = phoneNumber;

        return "User registered successfully.";
    }
}