/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
   Login login = new Login();

    // =========================
    // USERNAME TESTS
    // =========================

    // Test a valid username (contains "_" and <= 5 characters)
    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName("ab_cd"));
    }

    // Test an invalid username (no underscore or too long)
    @Test
    public void testCheckUserName_Invalid() {
        assertFalse(login.checkUserName("abcdef"));
    }

    // =========================
    // PASSWORD TESTS
    // =========================

    // Test a valid password (has capital letter, number, special character, and length >= 8)
    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(login.checkPasswordComplexity("Password@1"));
    }

    // Test an invalid password (missing requirements)
    @Test
    public void testCheckPasswordComplexity_Invalid() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    // =========================
    // PHONE NUMBER TESTS
    // =========================

    // Test a valid South African phone number (+27 and correct length)
    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    // Test an invalid phone number (missing +27)
    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    // =========================
    // REGISTER USER TESTS
    // =========================

    // Test successful registration with valid inputs
    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("ab_cd", "Password@1", "+27831234567");
        assertEquals("User registered successfully.", result);
    }

    // Test registration failure due to invalid username
    @Test
    public void testRegisterUser_InvalidUsername() {
        String result = login.registerUser("abcdef", "Password@1", "+27831234567");
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    // Test registration failure due to invalid password
    @Test
    public void testRegisterUser_InvalidPassword() {
        String result = login.registerUser("ab_cd", "pass", "+27831234567");
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    // Test registration failure due to invalid phone number
    @Test
    public void testRegisterUser_InvalidPhone() {
        String result = login.registerUser("ab_cd", "Password@1", "0831234567");
        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }

    // =========================
    // LOGIN TESTS
    // =========================

    // Test successful login after registering user
    @Test
    public void testLoginUser_Success() {
        // First register a user
        login.registerUser("ab_cd", "Password@1", "+27831234567");

        // Then attempt login with correct credentials
        assertTrue(login.loginUser("ab_cd", "Password@1"));
    }

    // Test login failure with incorrect password
    @Test
    public void testLoginUser_Failure() {
        // Register user
        login.registerUser("ab_cd", "Password@1", "+27831234567");

        // Attempt login with wrong password
        assertFalse(login.loginUser("ab_cd", "WrongPass"));
    }

    // =========================
    // LOGIN STATUS MESSAGE TESTS
    // =========================

    // Test success login message
    @Test
    public void testReturnLoginStatus_Success() {
        // Set username manually for message testing
        login.username = "ab_cd";

        String message = login.returnLoginStatus(true);

        // Check that welcome message contains username
        assertTrue(message.contains("Welcome ab_cd"));
    }

    // Test failure login message
    @Test
    public void testReturnLoginStatus_Failure() {
        String message = login.returnLoginStatus(false);

        // Check exact failure message
        assertEquals("Username or password invalid, please try again.", message);
    }
}
